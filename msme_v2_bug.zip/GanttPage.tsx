// src/pages/GanttPage.tsx — V2.0
// Gantt chart with:
//   - Jobs tab + Machines tab
//   - Status dots on bars and label column
//   - Blinking green dot for ready-to-start jobs
//   - Conflict banner, filter pills, today button, detail panel

import { useEffect, useRef, useState } from 'react'
import { fetchGanttData } from '../api/api_gantt'
import type { GanttJob } from '../api/api_gantt'

// ─── Constants ───────────────────────────────────────────────────────────────
const COL_W = 30
const ROW_H = 52
const LABEL_W = 220
const HEADER_H = 56

const JOB_COLORS = [
  '#0369a1', '#7c3aed', '#c2410c', '#0f766e',
  '#be185d', '#4d7c0f', '#4338ca', '#b45309',
]

const PRIORITY_ORDER: Record<string, number> = { high: 0, medium: 1, low: 2 }

// ─── Helpers ─────────────────────────────────────────────────────────────────
function getJobColor(idx: number) { return JOB_COLORS[idx % JOB_COLORS.length] }

function parseDate(s?: string): Date | null {
  if (!s) return null
  const d = new Date(s)
  return isNaN(d.getTime()) ? null : d
}

function daysBetween(a: Date, b: Date) {
  return Math.floor((b.getTime() - a.getTime()) / 86400000)
}

function addDays(d: Date, n: number) {
  const r = new Date(d); r.setDate(r.getDate() + n); return r
}

function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
}

function isWeekend(d: Date) { const w = d.getDay(); return w === 0 || w === 6 }

function formatDate(d: Date) {
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })
}

function monthLabel(d: Date) {
  return d.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })
}

// ─── Status dot SVG overlay on bar ───────────────────────────────────────────
// Returns a small SVG element (dot or arrow) to overlay on the bar's left side
function StatusDotSvg({ icon, x, y }: { icon: string; x: number; y: number }) {
  const cy = y + ROW_H / 2
  const cx = x + 10

  if (icon === 'in_progress') {
    return <polygon points={`${cx - 4},${cy - 5} ${cx + 6},${cy} ${cx - 4},${cy + 5}`} fill="#ffffff" opacity={0.9} />
  }

  const colors: Record<string, string> = {
    ready: '#86efac',       // green-300
    conflict: '#fca5a5',    // red-300
    completed: '#93c5fd',   // blue-300
    stopped: '#1f2937',     // gray-900
  }
  const fill = colors[icon] ?? '#e5e7eb'

  return <circle cx={cx} cy={cy} r={4} fill={fill} opacity={0.95} />
}

// Animated blinking dot for CSS — used in label column only
function BlinkDot({ icon }: { icon: string }) {
  const map: Record<string, { color: string; blink: boolean }> = {
    ready:      { color: 'bg-green-500', blink: true },
    conflict:   { color: 'bg-red-500',   blink: false },
    in_progress:{ color: 'bg-green-500', blink: false },
    completed:  { color: 'bg-blue-500',  blink: false },
    stopped:    { color: 'bg-gray-900',  blink: false },
  }
  const cfg = map[icon] ?? { color: 'bg-gray-400', blink: false }

  if (icon === 'in_progress') {
    return (
      <svg viewBox="0 0 12 12" className="w-3 h-3 flex-shrink-0">
        <polygon points="1,1 11,6 1,11" fill="#16a34a" />
      </svg>
    )
  }

  return (
    <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${cfg.color} ${cfg.blink ? 'animate-pulse' : ''}`} />
  )
}

type TabType = 'jobs' | 'machines'
type FilterPriority = 'all' | 'high' | 'medium' | 'low'

export default function GanttPage() {
  const [jobs, setJobs] = useState<GanttJob[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<TabType>('jobs')
  const [filterPriority, setFilterPriority] = useState<FilterPriority>('all')
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [selectedJob, setSelectedJob] = useState<GanttJob | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  const today = new Date(); today.setHours(0, 0, 0, 0)
  const rangeStart = new Date(today.getFullYear(), today.getMonth(), 1)
  const rangeEnd = new Date(today.getFullYear(), today.getMonth() + 2, 0)
  const totalDays = daysBetween(rangeStart, rangeEnd) + 1
  const days = Array.from({ length: totalDays }, (_, i) => addDays(rangeStart, i))

  useEffect(() => {
    fetchGanttData()
      .then(setJobs)
      .catch(e => setError(e?.message ?? 'Failed to load'))
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    if (!loading && scrollRef.current) {
      const offset = daysBetween(rangeStart, today) * COL_W - 100
      scrollRef.current.scrollLeft = Math.max(0, offset)
    }
  }, [loading])

  const scrollToToday = () => {
    if (scrollRef.current) {
      const offset = daysBetween(rangeStart, today) * COL_W - 100
      scrollRef.current.scrollLeft = Math.max(0, offset)
    }
  }

  const statuses = Array.from(new Set(jobs.map(j => j.status).filter(Boolean))) as string[]

  const filtered = jobs
    .filter(j => filterPriority === 'all' || j.priority?.toLowerCase() === filterPriority)
    .filter(j => filterStatus === 'all' || j.status === filterStatus)
    .sort((a, b) => {
      const pa = PRIORITY_ORDER[a.priority?.toLowerCase() ?? 'low'] ?? 2
      const pb = PRIORITY_ORDER[b.priority?.toLowerCase() ?? 'low'] ?? 2
      return pa - pb
    })

  const colorMap: Record<number, string> = {}
  jobs.forEach((j, i) => { colorMap[j.id] = getJobColor(i) })

  const machineGroups: Record<string, GanttJob[]> = {}
  if (activeTab === 'machines') {
    filtered.forEach(job => {
      const machines = job.assigned_machines.length ? job.assigned_machines : ['Unassigned']
      machines.forEach(m => {
        if (!machineGroups[m]) machineGroups[m] = []
        machineGroups[m].push(job)
      })
    })
  }

  const conflicting = filtered.filter(j => j.has_conflict)

  const chartHeight = activeTab === 'jobs'
    ? filtered.length * ROW_H
    : Object.keys(machineGroups).reduce((acc, k) => acc + (1 + machineGroups[k].length) * ROW_H, 0)

  const renderBar = (job: GanttJob, rowY: number) => {
    const start = parseDate(job.start_date)
    const end = parseDate(job.end_date)
    if (!start || !end) return null
    if (end < rangeStart || start > rangeEnd) return null

    const clampedStart = start < rangeStart ? rangeStart : start
    const clampedEnd = end > rangeEnd ? rangeEnd : end
    const x = daysBetween(rangeStart, clampedStart) * COL_W
    const w = (daysBetween(clampedStart, clampedEnd) + 1) * COL_W - 2
    if (w <= 0) return null

    const isConflict = job.has_conflict
    const color = isConflict ? '#fecaca' : colorMap[job.id]
    const textColor = isConflict ? '#991b1b' : '#ffffff'
    const isSelected = selectedJob?.id === job.id

    return (
      <g
        key={job.id}
        onClick={() => setSelectedJob(selectedJob?.id === job.id ? null : job)}
        style={{ cursor: 'pointer' }}
      >
        <rect
          x={x + 1} y={rowY + 10} width={w} height={ROW_H - 20}
          rx={6}
          fill={color}
          stroke={isSelected ? '#1d4ed8' : isConflict ? '#f87171' : 'transparent'}
          strokeWidth={isSelected ? 2 : 1}
          opacity={0.95}
        />
        {/* Status dot/arrow on bar */}
        <StatusDotSvg icon={job.status_icon} x={x} y={rowY} />

        {/* Label inside bar */}
        {w > 50 && (
          <text x={x + 20} y={rowY + ROW_H / 2 + 5} fill={textColor} fontSize={11} fontWeight={600}>
            {job.name.length > Math.floor((w - 22) / 7)
              ? job.name.slice(0, Math.floor((w - 22) / 7)) + '…'
              : job.name}
          </text>
        )}
      </g>
    )
  }

  if (loading) return (
    <div className="flex items-center justify-center h-64 gap-2">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      <span className="text-gray-500 text-sm">Loading Gantt…</span>
    </div>
  )

  if (error) return (
    <div className="m-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">⚠️ {error}</div>
  )

  return (
    <div className="flex flex-col h-full bg-white" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* Header */}
      <div className="px-6 pt-5 pb-3 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-gray-900">Production Schedule</h1>
            <p className="text-xs text-gray-400 mt-0.5">{monthLabel(rangeStart)} — {monthLabel(rangeEnd)}</p>
          </div>
          <button
            onClick={scrollToToday}
            className="px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 border border-blue-200 rounded-md hover:bg-blue-100 transition-colors"
          >
            Today
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 mt-4">
          {(['jobs', 'machines'] as TabType[]).map(tab => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab); setSelectedJob(null) }}
              className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors capitalize ${
                activeTab === tab ? 'bg-gray-900 text-white' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'
              }`}
            >
              {tab === 'jobs' ? 'Jobs' : 'Machines'}
            </button>
          ))}
        </div>
      </div>

      {/* Conflict banner */}
      {conflicting.length > 0 && (
        <div className="mx-6 mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
          <div className="flex items-start gap-2">
            <span className="text-red-500 mt-0.5">⚠️</span>
            <div>
              <p className="text-xs font-semibold text-red-700 mb-1">
                {conflicting.length} conflict{conflicting.length > 1 ? 's' : ''} detected
              </p>
              <ul className="space-y-0.5">
                {conflicting.map(j => (
                  <li key={j.id} className="text-xs text-red-600">
                    <span className="font-medium">{j.name}:</span>{' '}
                    {j.conflict_reasons.join('; ') || 'Resource double-booked'}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex items-center gap-4 px-6 py-3 border-b border-gray-100 flex-wrap">
        <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Priority</span>
        <div className="flex gap-1">
          {(['all', 'high', 'medium', 'low'] as FilterPriority[]).map(p => (
            <button
              key={p}
              onClick={() => setFilterPriority(p)}
              className={`px-3 py-1 text-xs font-medium rounded-full transition-colors capitalize ${
                filterPriority === p
                  ? p === 'high' ? 'bg-red-100 text-red-700 border border-red-300'
                  : p === 'medium' ? 'bg-yellow-100 text-yellow-700 border border-yellow-300'
                  : p === 'low' ? 'bg-green-100 text-green-700 border border-green-300'
                  : 'bg-gray-900 text-white'
                  : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
              }`}
            >
              {p === 'all' ? 'All' : p.charAt(0).toUpperCase() + p.slice(1)}
            </button>
          ))}
        </div>
        {statuses.length > 0 && (
          <>
            <span className="text-xs font-medium text-gray-400 uppercase tracking-wide ml-2">Status</span>
            <div className="flex gap-1 flex-wrap">
              {(['all', ...statuses]).map(s => (
                <button
                  key={s}
                  onClick={() => setFilterStatus(s)}
                  className={`px-3 py-1 text-xs font-medium rounded-full transition-colors capitalize ${
                    filterStatus === s ? 'bg-gray-900 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                  }`}
                >
                  {s === 'all' ? 'All' : s}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Chart area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Label column */}
        <div className="flex-shrink-0 border-r border-gray-200 overflow-hidden" style={{ width: LABEL_W }}>
          <div className="border-b border-gray-200 bg-gray-50 flex items-end px-3 pb-2" style={{ height: HEADER_H }}>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
              {activeTab === 'jobs' ? 'Job' : 'Machine / Job'}
            </span>
          </div>
          <div style={{ height: chartHeight, overflowY: 'hidden' }}>
            {activeTab === 'jobs' ? (
              filtered.map(job => (
                <div
                  key={job.id}
                  onClick={() => setSelectedJob(selectedJob?.id === job.id ? null : job)}
                  style={{ height: ROW_H }}
                  className={`flex items-center gap-2 px-3 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
                    selectedJob?.id === job.id ? 'bg-blue-50' : ''
                  }`}
                >
                  <BlinkDot icon={job.status_icon} />
                  <span
                    className="text-xs font-medium truncate"
                    style={{ color: job.has_conflict ? '#991b1b' : '#1f2937' }}
                    title={job.name}
                  >
                    {job.has_conflict && '⚠️ '}{job.name}
                  </span>
                </div>
              ))
            ) : (
              Object.entries(machineGroups).map(([machine, machineJobs]) => (
                <div key={machine}>
                  <div style={{ height: ROW_H }} className="flex items-center px-3 border-b border-gray-200 bg-gray-50">
                    <span className="text-xs font-semibold text-gray-600 uppercase tracking-wide truncate">🔧 {machine}</span>
                  </div>
                  {machineJobs.map(job => (
                    <div
                      key={job.id}
                      onClick={() => setSelectedJob(selectedJob?.id === job.id ? null : job)}
                      style={{ height: ROW_H }}
                      className={`flex items-center gap-2 pl-6 pr-3 border-b border-gray-100 cursor-pointer hover:bg-gray-50 transition-colors ${
                        selectedJob?.id === job.id ? 'bg-blue-50' : ''
                      }`}
                    >
                      <BlinkDot icon={job.status_icon} />
                      <span className="text-xs font-medium truncate" style={{ color: job.has_conflict ? '#991b1b' : '#374151' }} title={job.name}>
                        {job.has_conflict && '⚠️ '}{job.name}
                      </span>
                    </div>
                  ))}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Scrollable SVG chart */}
        <div ref={scrollRef} className="flex-1 overflow-x-auto overflow-y-hidden">
          <div style={{ width: totalDays * COL_W }}>
            {/* Date header */}
            <div className="sticky top-0 bg-gray-50 border-b border-gray-200 z-10" style={{ height: HEADER_H }}>
              <div className="flex" style={{ height: 22 }}>
                {days.reduce((acc: { month: string; count: number }[], d) => {
                  const m = monthLabel(d)
                  if (!acc.length || acc[acc.length - 1].month !== m) acc.push({ month: m, count: 1 })
                  else acc[acc.length - 1].count++
                  return acc
                }, []).map(({ month, count }, i) => (
                  <div key={i} style={{ width: count * COL_W }} className="flex items-center px-2 border-r border-gray-200 flex-shrink-0">
                    <span className="text-xs font-semibold text-gray-500">{month}</span>
                  </div>
                ))}
              </div>
              <div className="flex" style={{ height: HEADER_H - 22 }}>
                {days.map((d, i) => (
                  <div
                    key={i}
                    style={{ width: COL_W, minWidth: COL_W }}
                    className={`flex items-center justify-center border-r flex-shrink-0 ${
                      isWeekend(d) ? 'border-gray-200 bg-gray-100' : 'border-gray-100'
                    } ${isSameDay(d, today) ? 'bg-blue-50' : ''}`}
                  >
                    <span className={`text-xs ${isSameDay(d, today) ? 'font-bold text-blue-600' : isWeekend(d) ? 'text-gray-400' : 'text-gray-500'}`}>
                      {d.getDate()}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* SVG body */}
            <svg width={totalDays * COL_W} height={chartHeight} style={{ display: 'block' }}>
              {/* Weekend + today shading */}
              {days.map((d, i) => (
                <rect key={i} x={i * COL_W} y={0} width={COL_W} height={chartHeight}
                  fill={isSameDay(d, today) ? 'rgba(59,130,246,0.04)' : isWeekend(d) ? 'rgba(0,0,0,0.025)' : 'transparent'}
                />
              ))}

              {/* Row lines */}
              {activeTab === 'jobs' && filtered.map((_, i) => (
                <line key={i} x1={0} y1={(i + 1) * ROW_H} x2={totalDays * COL_W} y2={(i + 1) * ROW_H} stroke="#f3f4f6" strokeWidth={1} />
              ))}

              {/* Bars — Jobs */}
              {activeTab === 'jobs' && filtered.map((job, i) => renderBar(job, i * ROW_H))}

              {/* Bars — Machines */}
              {activeTab === 'machines' && (() => {
                let y = 0
                return Object.entries(machineGroups).map(([, machineJobs]) => {
                  y += ROW_H
                  return machineJobs.map(job => {
                    const bar = renderBar(job, y)
                    y += ROW_H
                    return bar
                  })
                })
              })()}

              {/* Today line */}
              {today >= rangeStart && today <= rangeEnd && (
                <line
                  x1={daysBetween(rangeStart, today) * COL_W + COL_W / 2} y1={0}
                  x2={daysBetween(rangeStart, today) * COL_W + COL_W / 2} y2={chartHeight}
                  stroke="#3b82f6" strokeWidth={1.5} strokeDasharray="4 3" opacity={0.7}
                />
              )}
            </svg>
          </div>
        </div>
      </div>

      {/* Detail panel */}
      {selectedJob && (
        <div className="border-t border-gray-200 bg-white px-6 py-4 shadow-inner">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <BlinkDot icon={selectedJob.status_icon} />
              <div>
                <h3 className="text-sm font-semibold text-gray-900">{selectedJob.name}</h3>
                {selectedJob.customer && <p className="text-xs text-gray-400">{selectedJob.customer}</p>}
              </div>
              {selectedJob.has_conflict && (
                <span className="px-2 py-0.5 text-xs font-medium bg-red-100 text-red-700 rounded-full">⚠️ Conflict</span>
              )}
            </div>
            <button onClick={() => setSelectedJob(null)} className="text-gray-400 hover:text-gray-600 text-lg leading-none">×</button>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-x-8 gap-y-1.5 text-xs">
            <div className="flex gap-2">
              <span className="text-gray-400 w-20 flex-shrink-0">Dates</span>
              <span className="text-gray-700">
                {selectedJob.start_date ? formatDate(new Date(selectedJob.start_date)) : '—'} →{' '}
                {selectedJob.end_date ? formatDate(new Date(selectedJob.end_date)) : '—'}
              </span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-400 w-20 flex-shrink-0">Status</span>
              <span className="text-gray-700 capitalize">{selectedJob.status || '—'}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-400 w-20 flex-shrink-0">Priority</span>
              <span className={`capitalize font-medium ${
                selectedJob.priority?.toLowerCase() === 'high' ? 'text-red-600'
                : selectedJob.priority?.toLowerCase() === 'medium' ? 'text-yellow-600'
                : 'text-green-600'
              }`}>{selectedJob.priority || '—'}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-400 w-20 flex-shrink-0">Employees</span>
              <span className="text-gray-700">{selectedJob.assigned_employees.join(', ') || 'None'}</span>
            </div>
            <div className="flex gap-2">
              <span className="text-gray-400 w-20 flex-shrink-0">Machines</span>
              <span className="text-gray-700">{selectedJob.assigned_machines.join(', ') || 'None'}</span>
            </div>
            {selectedJob.tentative_cost != null && (
              <div className="flex gap-2">
                <span className="text-gray-400 w-20 flex-shrink-0">Est. Cost</span>
                <span className="text-gray-700">₹{Math.round(selectedJob.tentative_cost).toLocaleString('en-IN')}</span>
              </div>
            )}
            {selectedJob.tentative_profit != null && (
              <div className="flex gap-2">
                <span className="text-gray-400 w-20 flex-shrink-0">Est. Profit</span>
                <span className={selectedJob.tentative_profit >= 0 ? 'text-green-600 font-medium' : 'text-red-500 font-medium'}>
                  ₹{Math.round(selectedJob.tentative_profit).toLocaleString('en-IN')}
                </span>
              </div>
            )}
          </div>
          {selectedJob.has_conflict && selectedJob.conflict_reasons.length > 0 && (
            <div className="mt-3 p-2.5 bg-red-50 border border-red-100 rounded-lg">
              <p className="text-xs font-semibold text-red-700 mb-1">Conflict Details</p>
              <ul className="space-y-0.5">
                {selectedJob.conflict_reasons.map((r, i) => (
                  <li key={i} className="text-xs text-red-600">• {r}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {!loading && filtered.length === 0 && (
        <div className="flex flex-col items-center justify-center flex-1 text-gray-400 gap-2">
          <span className="text-3xl">📋</span>
          <p className="text-sm font-medium">No jobs match the current filters</p>
        </div>
      )}
    </div>
  )
}
