"""
routers/assignments.py — V1.1
Added: JWT auth, tenant_id scoping on all endpoints
  POST /api/assignments/                        — scheduler+
  GET  /api/assignments/check/{job_id}          — any authenticated user
  GET  /api/assignments/employee/{employee_id}  — any authenticated user
  GET  /api/assignments/machine/{machine_id}    — any authenticated user
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List

from app.database import get_db
from app.core.dependencies import get_current_user, require_role
from app.models.auth import User
from app.services.assignment_service import assign_resources, AssignmentError
from app.services.availability_engine import (
    check_availability, _date_range, _effective_availability,
    _is_employee_busy, _is_machine_busy,
)
from app.models.job import JobAssignment, Job, JobSkillRequirement
from app.models.employee import Employee
from app.models.machine import Machine
from app.models.availability import AvailabilityOverride

router = APIRouter()


class AssignRequest(BaseModel):
    job_id: int
    employee_ids: List[int] = []
    machine_ids: List[int] = []


@router.post("/", status_code=status.HTTP_201_CREATED)
def create_assignment(
    payload: AssignRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_role("proprietor", "scheduler")),  # ← ADDED
):
    try:
        result = assign_resources(
            db=db,
            job_id=payload.job_id,
            employee_ids=payload.employee_ids,
            machine_ids=payload.machine_ids,
            tenant_id=current_user.tenant_id,      # ← ADDED
        )
        return {"message": "Resources assigned successfully", "assignments": result}
    except AssignmentError as e:
        raise HTTPException(status_code=409, detail=str(e))


@router.get("/check/{job_id}")
def check_job_availability(
    job_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),     # ← ADDED
):
    job = db.query(Job).filter(
        Job.id == job_id,
        Job.tenant_id == current_user.tenant_id,        # ← tenant scoped
    ).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    try:
        result = check_availability(db, job_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))

    days = _date_range(job.start_date, job.end_date)

    # --- Machines scoped to tenant ---
    all_machines = db.query(Machine).filter(
        Machine.tenant_id == current_user.tenant_id,    # ← tenant scoped
        Machine.status == "Operational",
    ).all()
    machines_info = []
    for m in all_machines:
        overrides = db.query(AvailabilityOverride).filter(AvailabilityOverride.machine_id == m.id).all()
        blocked = any(_effective_availability(m.base_availability_pct, overrides, d) <= 0 for d in days)
        busy = _is_machine_busy(db, m.id, job_id, days)
        machines_info.append({
            "id": m.id,
            "name": m.name,
            "machine_type": m.machine_type,
            "location_bay": m.location_bay,
            "hourly_rate": m.hourly_rate,
            "available": not blocked and not busy,
            "busy_reason": "On maintenance/override" if blocked else ("Assigned to another job" if busy else None),
            "skill_requirements": [
                {
                    "skill_id": sr.skill_id,
                    "skill_name": sr.skill.name if sr.skill else f"skill#{sr.skill_id}",
                    "min_skill_level": sr.min_skill_level,
                    "employees_required": sr.employees_required,
                }
                for sr in m.skill_requirements
            ],
        })

    # --- Employees scoped to tenant ---
    all_employees = db.query(Employee).filter(
        Employee.tenant_id == current_user.tenant_id,   # ← tenant scoped
        Employee.status == "Active",
    ).all()
    employees_info = []
    for emp in all_employees:
        overrides = db.query(AvailabilityOverride).filter(AvailabilityOverride.employee_id == emp.id).all()
        blocked = any(_effective_availability(emp.base_availability_pct, overrides, d) <= 0 for d in days)
        busy = _is_employee_busy(db, emp.id, job_id, days)
        employees_info.append({
            "id": emp.id,
            "full_name": emp.full_name,
            "department": emp.department,
            "employment_type": emp.employment_type,
            "hourly_rate": emp.hourly_rate,
            "available": not blocked and not busy,
            "busy_reason": "Unavailable/on leave" if blocked else ("Assigned to another job" if busy else None),
            "skills": [
                {
                    "skill_id": es.skill_id,
                    "skill_name": es.skill.name if es.skill else f"skill#{es.skill_id}",
                    "skill_level": es.skill_level,
                }
                for es in emp.skills
            ],
        })

    # --- Skill requirements ---
    skill_reqs = db.query(JobSkillRequirement).filter(
        JobSkillRequirement.job_id == job_id,
    ).all()
    skill_reqs_info = []
    for req in skill_reqs:
        avail_ids = result.available_employees.get(req.id, [])
        skill_reqs_info.append({
            "id": req.id,
            "skill_id": req.skill_id,
            "skill_name": req.skill.name if req.skill else f"skill#{req.skill_id}",
            "min_skill_level": req.min_skill_level,
            "employees_required": req.employees_required,
            "available_employee_ids": avail_ids,
        })

    # --- Currently assigned ---
    current = db.query(JobAssignment).filter(
        JobAssignment.job_id == job_id,
        JobAssignment.tenant_id == current_user.tenant_id,  # ← tenant scoped
    ).all()
    current_emp_ids = [a.employee_id for a in current if a.employee_id]
    current_machine_ids = [a.machine_id for a in current if a.machine_id]

    return {
        "job_id": job_id,
        "feasible": result.feasible,
        "feasibility_score": result.feasibility_score,
        "conflicts": [
            {"resource_type": c.resource_type, "resource_name": c.resource_name, "reason": c.reason}
            for c in result.conflicts
        ],
        "skill_requirements": skill_reqs_info,
        "machines": machines_info,
        "employees": employees_info,
        "currently_assigned_employee_ids": current_emp_ids,
        "currently_assigned_machine_ids": current_machine_ids,
    }


@router.get("/employee/{employee_id}")
def get_employee_assignments(
    employee_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),     # ← ADDED
):
    emp = db.query(Employee).filter(
        Employee.id == employee_id,
        Employee.tenant_id == current_user.tenant_id,   # ← tenant scoped
    ).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    rows = (
        db.query(JobAssignment)
        .filter(
            JobAssignment.employee_id == employee_id,
            JobAssignment.tenant_id == current_user.tenant_id,  # ← tenant scoped
        )
        .join(Job, JobAssignment.job_id == Job.id)
        .order_by(Job.start_date)
        .all()
    )
    return [
        {
            "assignment_id": r.id,
            "job_id": r.job.id,
            "job_name": r.job.name,
            "customer": r.job.customer,
            "start_date": str(r.job.start_date),
            "end_date": str(r.job.end_date),
            "status": r.job.status,
            "priority": r.job.priority,
            "assigned_at": r.assigned_at.isoformat() if r.assigned_at else None,
        }
        for r in rows
    ]


@router.get("/machine/{machine_id}")
def get_machine_assignments(
    machine_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),     # ← ADDED
):
    machine = db.query(Machine).filter(
        Machine.id == machine_id,
        Machine.tenant_id == current_user.tenant_id,    # ← tenant scoped
    ).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")

    rows = (
        db.query(JobAssignment)
        .filter(
            JobAssignment.machine_id == machine_id,
            JobAssignment.tenant_id == current_user.tenant_id,  # ← tenant scoped
        )
        .join(Job, JobAssignment.job_id == Job.id)
        .order_by(Job.start_date)
        .all()
    )
    return [
        {
            "assignment_id": r.id,
            "job_id": r.job.id,
            "job_name": r.job.name,
            "customer": r.job.customer,
            "start_date": str(r.job.start_date),
            "end_date": str(r.job.end_date),
            "status": r.job.status,
            "priority": r.job.priority,
            "assigned_at": r.assigned_at.isoformat() if r.assigned_at else None,
        }
        for r in rows
    ]
