"""
services/availability_engine.py
--------------------------------
Core scheduling logic implementing the 5-step availability check from SRS §4.6.
This module is read-only — it queries the DB and returns structured results without
making any changes. All scheduling decisions remain deterministic and side-effect free.

Steps performed:
  1. Machine Check       — verify each required machine is available on every job day
  2. Employee Skill Match — find employees who hold the required skill at or above the required level
  3. Employee Capacity Check — exclude employees already booked on another job in the same range
  4. Conflict Report     — collect all failures into a structured list
  5. Feasibility Score   — compute 0–100% score = requirements_met / requirements_total
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import List, Dict
from sqlalchemy.orm import Session

from app.models.job import Job, JobSkillRequirement, JobAssignment
from app.models.employee import Employee, EmployeeSkill
from app.models.machine import Machine
from app.models.availability import AvailabilityOverride


# ---------------------------------------------------------------------------
# Skill level ranking — used to evaluate if a candidate meets the requirement
# ---------------------------------------------------------------------------
SKILL_LEVEL_RANK = {"Generic": 1, "Intermediate": 2, "Premium": 3}


def _level_meets(candidate_level: str, required_level: str) -> bool:
    """
    Return True if the candidate's skill level is equal to or higher than required.

    Input  : candidate_level (e.g. "Intermediate"), required_level (e.g. "Generic").
    Output : bool — True means the candidate qualifies.
    """
    return SKILL_LEVEL_RANK.get(candidate_level, 0) >= SKILL_LEVEL_RANK.get(required_level, 0)


# ---------------------------------------------------------------------------
# Date utilities
# ---------------------------------------------------------------------------
def _date_range(start: date, end: date) -> List[date]:
    """
    Generate a list of every calendar date from start to end, inclusive.

    Input  : start date, end date.
    Output : List[date] in ascending order.
    """
    days, current = [], start
    while current <= end:
        days.append(current)
        current += timedelta(days=1)
    return days


def _effective_availability(base_pct: float, overrides: List[AvailabilityOverride], d: date) -> float:
    """
    Compute the effective availability % for a resource on a specific date.
    Applies the SRS rule: effective = min(base_pct, override_pct) for any matching override.

    Input  : base_pct (0–100 float), list of AvailabilityOverride ORM objects, target date.
    Output : float — effective availability %, possibly reduced by an active override.
    """
    effective = base_pct
    for override in overrides:
        if override.date_from <= d <= override.date_to:
            effective = min(effective, override.availability_pct)
    return effective


def _is_employee_busy(db: Session, employee_id: int, job_id: int, days: List[date]) -> bool:
    """
    Check whether an employee is already assigned to a different job that overlaps these days.

    Input  : db session, employee_id, job_id to exclude (the job being checked), list of dates.
    Output : bool — True means the employee is already committed and cannot be used.
    """
    assignments = (
        db.query(JobAssignment)
        .filter(JobAssignment.employee_id == employee_id, JobAssignment.job_id != job_id)
        .all()
    )
    for assignment in assignments:
        other_job = db.query(Job).filter(Job.id == assignment.job_id).first()
        if other_job:
            other_days = set(_date_range(other_job.start_date, other_job.end_date))
            if any(d in other_days for d in days):
                return True
    return False


def _is_machine_busy(db: Session, machine_id: int, job_id: int, days: List[date]) -> bool:
    """
    Check whether a machine is already assigned to a different job that overlaps these days.

    Input  : db session, machine_id, job_id to exclude, list of dates.
    Output : bool — True means the machine is already committed and cannot be used.
    """
    assignments = (
        db.query(JobAssignment)
        .filter(JobAssignment.machine_id == machine_id, JobAssignment.job_id != job_id)
        .all()
    )
    for assignment in assignments:
        other_job = db.query(Job).filter(Job.id == assignment.job_id).first()
        if other_job:
            other_days = set(_date_range(other_job.start_date, other_job.end_date))
            if any(d in other_days for d in days):
                return True
    return False


# ---------------------------------------------------------------------------
# Result data classes
# ---------------------------------------------------------------------------
@dataclass
class ConflictDetail:
    """One conflict found during the availability check — describes what failed and why."""
    resource_type: str       # "machine" | "employee"
    resource_id: int
    resource_name: str
    dates: List[str]         # ISO date strings of the blocked days
    reason: str              # Human-readable explanation


@dataclass
class AvailabilityResult:
    """Full result returned by check_availability() for one job."""
    job_id: int
    feasible: bool                                   # True only when conflicts list is empty
    feasibility_score: float                         # 0.0 – 100.0
    conflicts: List[ConflictDetail] = field(default_factory=list)
    available_employees: Dict[int, List[int]] = field(default_factory=dict)
    # available_employees maps: JobSkillRequirement.id → [employee_id, ...]


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def check_availability(db: Session, job_id: int) -> AvailabilityResult:
    """
    Run the full 5-step availability check for a job as defined in SRS §4.6.

    Step 1 — For each machine already tentatively assigned to the job, verify it
             is available (>0%) on every day and not committed to another job.
    Step 2 — For each JobSkillRequirement, find employees who hold that skill at
             the required level or above AND are Active.
    Step 3 — From those candidates, filter out anyone unavailable on any day
             or already fully booked on another job in the same date range.
    Step 4 — Collect every failed check into a ConflictDetail list.
    Step 5 — Compute feasibility_score = (requirements_met / requirements_total) * 100.

    Input  : db session, job_id (int).
    Output : AvailabilityResult with feasibility_score, feasible flag, conflict list,
             and a mapping of skill requirement IDs to lists of qualifying employee IDs.
             Raises ValueError if the job_id does not exist.
    """
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise ValueError(f"Job {job_id} not found")

    days = _date_range(job.start_date, job.end_date)
    conflicts: List[ConflictDetail] = []
    requirements_total = 0
    requirements_met = 0
    available_employees: Dict[int, List[int]] = {}

    # --- Step 1: Machine Check ---
    existing_machine_assignments = (
        db.query(JobAssignment)
        .filter(JobAssignment.job_id == job_id, JobAssignment.machine_id.isnot(None))
        .all()
    )
    for assignment in existing_machine_assignments:
        machine = db.query(Machine).filter(Machine.id == assignment.machine_id).first()
        if not machine:
            continue
        requirements_total += 1
        machine_overrides = (
            db.query(AvailabilityOverride)
            .filter(AvailabilityOverride.machine_id == machine.id)
            .all()
        )
        # Collect any days where the machine is unavailable due to overrides
        blocked_dates = [
            str(d) for d in days
            if _effective_availability(machine.base_availability_pct, machine_overrides, d) <= 0
        ]
        if blocked_dates:
            conflicts.append(ConflictDetail(
                resource_type="machine", resource_id=machine.id, resource_name=machine.name,
                dates=blocked_dates, reason="Machine unavailable (maintenance/override)",
            ))
        elif _is_machine_busy(db, machine.id, job_id, days):
            conflicts.append(ConflictDetail(
                resource_type="machine", resource_id=machine.id, resource_name=machine.name,
                dates=[str(d) for d in days],
                reason="Machine already assigned to another job in this date range",
            ))
        else:
            requirements_met += 1

    # --- Steps 2 & 3: Employee Skill Match + Capacity Check ---
    skill_requirements: List[JobSkillRequirement] = (
        db.query(JobSkillRequirement).filter(JobSkillRequirement.job_id == job_id).all()
    )
    for req in skill_requirements:
        requirements_total += req.employees_required

        # Find all Active employees who hold this skill
        candidates = (
            db.query(Employee)
            .join(EmployeeSkill, EmployeeSkill.employee_id == Employee.id)
            .filter(EmployeeSkill.skill_id == req.skill_id, Employee.status == "Active")
            .all()
        )

        qualified: List[int] = []
        for emp in candidates:
            # Check the employee's skill level meets or exceeds the requirement
            emp_skill = (
                db.query(EmployeeSkill)
                .filter(EmployeeSkill.employee_id == emp.id, EmployeeSkill.skill_id == req.skill_id)
                .first()
            )
            if not emp_skill or not _level_meets(emp_skill.skill_level, req.min_skill_level):
                continue

            # Check the employee is available on every day in the job range
            emp_overrides = (
                db.query(AvailabilityOverride)
                .filter(AvailabilityOverride.employee_id == emp.id)
                .all()
            )
            if any(_effective_availability(emp.base_availability_pct, emp_overrides, d) <= 0 for d in days):
                continue

            # Check the employee is not double-booked on another job
            if _is_employee_busy(db, emp.id, job_id, days):
                continue

            qualified.append(emp.id)

        available_employees[req.id] = qualified
        requirements_met += min(len(qualified), req.employees_required)

        # Step 4: record a conflict if we cannot find enough qualified employees
        if len(qualified) < req.employees_required:
            skill_name = req.skill.name if req.skill else f"skill#{req.skill_id}"
            conflicts.append(ConflictDetail(
                resource_type="employee", resource_id=req.skill_id,
                resource_name=f"Skill: {skill_name} (need {req.employees_required}, found {len(qualified)})",
                dates=[str(d) for d in days],
                reason=f"Insufficient qualified employees for '{skill_name}' at '{req.min_skill_level}' level",
            ))

    # --- Step 5: Feasibility Score ---
    feasibility_score = (requirements_met / requirements_total * 100) if requirements_total > 0 else 100.0

    return AvailabilityResult(
        job_id=job_id,
        feasible=len(conflicts) == 0,
        feasibility_score=round(feasibility_score, 1),
        conflicts=conflicts,
        available_employees=available_employees,
    )
