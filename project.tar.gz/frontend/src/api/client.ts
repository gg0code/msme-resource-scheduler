// src/api/client.ts
// -----------------
// Axios instance pre-configured with the base URL for all API calls.
// All API modules import this client so the base URL is defined in one place.
// The proxy in vite.config.ts forwards /api/* to http://localhost:8000 in dev.

import axios from 'axios'

const apiClient = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
})

export default apiClient
