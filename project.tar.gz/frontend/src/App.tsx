import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Skills from './pages/Skills'
import Employees from './pages/Employees'
import Machines from './pages/Machines'
import Jobs from './pages/Jobs'
import Availability from './pages/Availability'
import Checker from './pages/Checker'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard"    element={<Dashboard />} />
        <Route path="jobs"         element={<Jobs />} />
        <Route path="employees"    element={<Employees />} />
        <Route path="machines"     element={<Machines />} />
        <Route path="availability" element={<Availability />} />
        <Route path="checker"      element={<Checker />} />
        <Route path="skills"       element={<Skills />} />
      </Route>
    </Routes>
  )
}
