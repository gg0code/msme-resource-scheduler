import { Outlet, NavLink } from 'react-router-dom'
import { LayoutDashboard, Wrench, Users, Settings, BriefcaseBusiness, Factory, CalendarOff, ShieldCheck } from 'lucide-react'

const navItems = [
  { to:'/dashboard',    label:'Dashboard',      icon:LayoutDashboard  },
  { to:'/jobs',         label:'Jobs',           icon:BriefcaseBusiness },
  { to:'/employees',    label:'Employees',      icon:Users             },
  { to:'/machines',     label:'Machines',       icon:Factory           },
  { to:'/availability', label:'Availability',   icon:CalendarOff       },
  { to:'/checker',      label:'Avail. Checker', icon:ShieldCheck       },
  { to:'/skills',       label:'Skills',         icon:Settings          },
]

export default function Layout() {
  return (
    <div className="flex h-screen bg-gray-50 font-sans">
      <aside className="w-56 bg-gray-900 text-white flex flex-col shrink-0">
        <div className="px-5 py-5 border-b border-gray-700">
          <div className="flex items-center gap-2">
            <Wrench className="text-blue-400" size={20}/>
            <span className="font-bold text-sm leading-tight">MSME<br/><span className="text-blue-400 font-semibold">Resource Scheduler</span></span>
          </div>
        </div>
        <nav className="flex-1 py-4 px-2 space-y-1">
          {navItems.map(({to,label,icon:Icon})=>(
            <NavLink key={to} to={to}
              className={({isActive})=>`flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors ${isActive?'bg-blue-600 text-white font-medium':'text-gray-300 hover:bg-gray-700 hover:text-white'}`}>
              <Icon size={17}/>{label}
            </NavLink>
          ))}
        </nav>
        <div className="px-5 py-3 border-t border-gray-700 text-xs text-gray-500">v1.0.0 — Local Dev</div>
      </aside>
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between shrink-0">
          <h1 className="text-gray-700 font-semibold text-sm">MSME Resource Scheduler</h1>
          <span className="text-xs text-gray-400">Local — No Auth (V1.0)</span>
        </header>
        <main className="flex-1 overflow-y-auto p-6"><Outlet/></main>
      </div>
    </div>
  )
}
