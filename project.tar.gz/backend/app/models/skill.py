"""
models/skill.py
---------------
ORM model for the Skill Catalogue — the master list of skills that employees
can possess and machines can require. Each skill has a category (generic/premium)
and an active flag so skills can be soft-deleted without breaking existing records.
"""

from sqlalchemy import Column, Integer, String, Boolean, Text, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base


class Skill(Base):
    """
    Represents a single skill entry in the tenant's skill catalogue.

    Table  : skills
    Key relationships:
      - EmployeeSkill  (many employees can have this skill)
      - MachineSkillRequirement  (many machines can require this skill)
      - JobSkillRequirement  (many jobs can require this skill)
    """

    __tablename__ = "skills"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, unique=True)
    category = Column(String(20), nullable=False)   # "generic" | "premium"
    is_premium = Column(Boolean, default=False, nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    employee_skills = relationship("EmployeeSkill", back_populates="skill")
    machine_skill_requirements = relationship("MachineSkillRequirement", back_populates="skill")
    job_skill_requirements = relationship("JobSkillRequirement", back_populates="skill")
