"""
models/availability.py
----------------------
ORM model for availability overrides — day-specific availability percentages that
override an employee's or machine's base availability for a given date range.
Used to record planned leave, half-days, and scheduled machine maintenance.
"""

from sqlalchemy import Column, Integer, Float, Date, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base


class AvailabilityOverride(Base):
    """
    A date-range override that adjusts effective availability for one resource.

    Table  : availability_overrides
    Either employee_id or machine_id must be set (not both).
    The availability engine applies: effective_pct = min(base_pct, override_pct)
    for any date that falls within [date_from, date_to].

    Examples:
      - Employee on leave 20–25 March  → availability_pct = 0
      - Machine partial maintenance 1 April → availability_pct = 50
    """

    __tablename__ = "availability_overrides"

    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id", ondelete="CASCADE"), nullable=True)
    machine_id = Column(Integer, ForeignKey("machines.id", ondelete="CASCADE"), nullable=True)
    date_from = Column(Date, nullable=False)
    date_to = Column(Date, nullable=False)          # For a single day: date_from == date_to
    availability_pct = Column(Float, nullable=False, default=0.0)   # 0 = fully unavailable
    reason = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    employee = relationship("Employee", back_populates="availability_overrides", foreign_keys=[employee_id])
    machine = relationship("Machine", back_populates="availability_overrides", foreign_keys=[machine_id])
