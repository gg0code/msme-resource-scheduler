"""
main.py
-------
FastAPI application entry point for the MSME Resource Scheduler backend.
Registers all routers, configures CORS to allow the React frontend, and
mounts the OpenAPI docs at /api/docs. Run with: uvicorn app.main:app --reload --port 8000
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings
from app.routers import skills, employees, machines, jobs, assignments, availability, dashboard

# ---------------------------------------------------------------------------
# App initialisation
# ---------------------------------------------------------------------------
# Creates the FastAPI instance with project metadata. OpenAPI schema is served
# at /api/openapi.json and interactive docs at /api/docs (Swagger) and /api/redoc.
app = FastAPI(
    title="MSME Resource Scheduler API",
    description="Resource Assignment & Profit Optimization Platform",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

# ---------------------------------------------------------------------------
# CORS middleware
# ---------------------------------------------------------------------------
# Allows the React Vite dev server (localhost:3000) to call this API.
# In production, replace with the actual frontend domain.
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        f"http://localhost:{settings.FRONTEND_PORT}",
        "http://localhost:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Router registration
# ---------------------------------------------------------------------------
# Each router handles one domain resource. All routes are namespaced under /api/
# so they are easy to proxy behind Nginx in production.
app.include_router(skills.router,       prefix="/api/skills",       tags=["Skills"])
app.include_router(employees.router,    prefix="/api/employees",    tags=["Employees"])
app.include_router(machines.router,     prefix="/api/machines",     tags=["Machines"])
app.include_router(jobs.router,         prefix="/api/jobs",         tags=["Jobs"])
app.include_router(assignments.router,  prefix="/api/assignments",  tags=["Assignments"])
app.include_router(availability.router, prefix="/api/availability", tags=["Availability"])
app.include_router(dashboard.router,    prefix="/api/dashboard",    tags=["Dashboard"])


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------
@app.get("/api/health", tags=["Health"])
def health_check():
    """
    Simple liveness probe used by Docker healthchecks and load balancers.

    Input  : None.
    Output : JSON with status "ok" and the current API version string.
    """
    return {"status": "ok", "version": "1.0.0"}
