"""
routers/dashboard.py
--------------------
HTTP route handler for the Dashboard summary endpoint (GET /api/dashboard/).
Aggregates key metrics from the database — active job counts, available resource
counts, status breakdowns, and the upcoming job list for the next 7 days.
This is the first endpoint called when the React dashboard page loads.
"""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from datetime import date, timedelta

from app.database import get_db
from app.models.job import Job
from app.models.employee import Employee
from app.models.machine import Machine

router = APIRouter()


@router.get("/")
def get_dashboard(db: Session = Depends(get_db)):
    """
    Return a consolidated summary of the scheduler's current state.

    Aggregates:
      - total_active_jobs       : count of Scheduled + In Progress jobs
      - available_machines      : count of Operational machines
      - available_employees     : count of Active employees
      - jobs_by_status          : dict mapping each status string to its job count
      - upcoming_jobs_this_week : jobs starting within the next 7 days, ordered by start_date

    Input  : None (no query params required).
    Output : JSON object with the five aggregated fields described above.
             The upcoming_jobs list includes id, name, dates, priority, status,
             and tentative_profit for each job.
    """
    today = date.today()
    week_end = today + timedelta(days=7)

    # Count jobs currently active (being worked on or fully scheduled)
    total_active_jobs = db.query(Job).filter(
        Job.status.in_(["Scheduled", "In Progress"])
    ).count()

    # Build a status → count dict by scanning all jobs
    status_counts = {}
    for job in db.query(Job).all():
        status_counts[job.status] = status_counts.get(job.status, 0) + 1

    # Count resources that are currently available for scheduling
    available_machines = db.query(Machine).filter(Machine.status == "Operational").count()
    available_employees = db.query(Employee).filter(Employee.status == "Active").count()

    # Fetch jobs starting within the next 7 days that still need attention
    upcoming_jobs = db.query(Job).filter(
        Job.start_date >= today,
        Job.start_date <= week_end,
        Job.status.in_(["Scheduled", "Pending Assignment"]),
    ).order_by(Job.start_date).all()

    return {
        "total_active_jobs": total_active_jobs,
        "available_machines": available_machines,
        "available_employees": available_employees,
        "jobs_by_status": status_counts,
        "upcoming_jobs_this_week": [
            {
                "id": j.id,
                "name": j.name,
                "start_date": str(j.start_date),
                "end_date": str(j.end_date),
                "priority": j.priority,
                "status": j.status,
                "tentative_profit": j.tentative_profit,
            }
            for j in upcoming_jobs
        ],
    }
