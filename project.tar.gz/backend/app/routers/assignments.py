"""
routers/assignments.py
----------------------
HTTP route handler for the Resource Assignment API (POST only in V1).
Accepts a job ID along with lists of employee and machine IDs, delegates
all validation and conflict checking to the assignment_service, and returns
the created assignment records or a 409 conflict error with a clear message.
All routes are mounted at /api/assignments/ in main.py.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import List

from app.database import get_db
from app.services.assignment_service import assign_resources, AssignmentError

router = APIRouter()


class AssignRequest(BaseModel):
    """
    Request body for POST /api/assignments/.

    Fields:
      job_id        — the job to assign resources to.
      employee_ids  — list of employee primary keys to assign.
      machine_ids   — list of machine primary keys to assign.
    """
    job_id: int
    employee_ids: List[int] = []
    machine_ids: List[int] = []


@router.post("/", status_code=status.HTTP_201_CREATED)
def create_assignment(payload: AssignRequest, db: Session = Depends(get_db)):
    """
    Assign employees and machines to a job after validating availability.
    Delegates all conflict-detection logic to the assignment_service layer.

    Input  : AssignRequest JSON body (job_id, employee_ids, machine_ids).
    Output : Success message with list of created assignment dicts on HTTP 201;
             raises HTTP 409 Conflict with a human-readable reason if any
             resource is unavailable or already double-booked.
    """
    try:
        result = assign_resources(
            db=db,
            job_id=payload.job_id,
            employee_ids=payload.employee_ids,
            machine_ids=payload.machine_ids,
        )
        return {"message": "Resources assigned successfully", "assignments": result}
    except AssignmentError as e:
        raise HTTPException(status_code=409, detail=str(e))


# ── New: per-resource schedule views ───────────────────

from app.models.job import JobAssignment, Job
from app.models.employee import Employee
from app.models.machine import Machine


@router.get("/employee/{employee_id}")
def get_employee_assignments(employee_id: int, db: Session = Depends(get_db)):
    """
    Return all jobs assigned to a specific employee.
    GET /api/assignments/employee/{employee_id}
    """
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")

    rows = (
        db.query(JobAssignment)
        .filter(JobAssignment.employee_id == employee_id)
        .join(Job, JobAssignment.job_id == Job.id)
        .order_by(Job.start_date)
        .all()
    )
    return [
        {
            "assignment_id": r.id,
            "job_id":        r.job.id,
            "job_name":      r.job.name,
            "customer":      r.job.customer,
            "start_date":    str(r.job.start_date),
            "end_date":      str(r.job.end_date),
            "status":        r.job.status,
            "priority":      r.job.priority,
            "assigned_at":   r.assigned_at.isoformat() if r.assigned_at else None,
        }
        for r in rows
    ]


@router.get("/machine/{machine_id}")
def get_machine_assignments(machine_id: int, db: Session = Depends(get_db)):
    """
    Return all jobs assigned to a specific machine.
    GET /api/assignments/machine/{machine_id}
    """
    machine = db.query(Machine).filter(Machine.id == machine_id).first()
    if not machine:
        raise HTTPException(status_code=404, detail="Machine not found")

    rows = (
        db.query(JobAssignment)
        .filter(JobAssignment.machine_id == machine_id)
        .join(Job, JobAssignment.job_id == Job.id)
        .order_by(Job.start_date)
        .all()
    )
    return [
        {
            "assignment_id": r.id,
            "job_id":        r.job.id,
            "job_name":      r.job.name,
            "customer":      r.job.customer,
            "start_date":    str(r.job.start_date),
            "end_date":      str(r.job.end_date),
            "status":        r.job.status,
            "priority":      r.job.priority,
            "assigned_at":   r.assigned_at.isoformat() if r.assigned_at else None,
        }
        for r in rows
    ]
