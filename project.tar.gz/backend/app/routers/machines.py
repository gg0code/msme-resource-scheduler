"""
routers/machines.py
-------------------
HTTP route handlers for the Machine Master API (GET, POST, PATCH, DELETE).
Machine creation and updates accept an embedded skill requirement list; the
_sync_skill_reqs helper replaces all MachineSkillRequirement rows atomically.
All routes are mounted at /api/machines/ in main.py.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.machine import Machine, MachineSkillRequirement
from app.schemas.machine import MachineCreate, MachineUpdate, MachineOut

router = APIRouter()


def _sync_skill_reqs(db: Session, machine: Machine, reqs: list):
    """
    Replace all MachineSkillRequirement rows for this machine with a new list.
    Called inside create and update routes to keep skill requirements in sync.

    Input  : db session, machine ORM object, list of MachineSkillReqIn objects.
    Output : None — deletes existing requirement rows and inserts new ones in-place.
    """
    db.query(MachineSkillRequirement).filter(MachineSkillRequirement.machine_id == machine.id).delete()
    for r in reqs:
        db.add(MachineSkillRequirement(
            machine_id=machine.id,
            skill_id=r.skill_id,
            min_skill_level=r.min_skill_level,
            employees_required=r.employees_required,
        ))


@router.get("/", response_model=List[MachineOut])
def list_machines(status: str = None, db: Session = Depends(get_db)):
    """
    Return all machines, optionally filtered by operational status.

    Input  : status (query param, e.g. "Operational", "Under Maintenance"). Optional.
    Output : List of MachineOut objects with embedded skill requirements, ordered by name.
    """
    q = db.query(Machine)
    if status:
        q = q.filter(Machine.status == status)
    return q.order_by(Machine.name).all()


@router.get("/{machine_id}", response_model=MachineOut)
def get_machine(machine_id: int, db: Session = Depends(get_db)):
    """
    Fetch a single machine by primary key.

    Input  : machine_id (path param).
    Output : MachineOut with embedded skill requirements; raises HTTP 404 if not found.
    """
    m = db.query(Machine).filter(Machine.id == machine_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Machine not found")
    return m


@router.post("/", response_model=MachineOut, status_code=status.HTTP_201_CREATED)
def create_machine(payload: MachineCreate, db: Session = Depends(get_db)):
    """
    Create a new machine and optionally set its skill requirements in one request.

    Input  : MachineCreate JSON body (machine fields + optional skill_requirements list).
    Output : Newly created MachineOut with assigned id and embedded skill requirements.
    """
    data = payload.model_dump(exclude={"skill_requirements"})
    machine = Machine(**data)
    db.add(machine)
    db.flush()   # Get machine.id for FK in MachineSkillRequirement
    _sync_skill_reqs(db, machine, payload.skill_requirements)
    db.commit()
    db.refresh(machine)
    return machine


@router.patch("/{machine_id}", response_model=MachineOut)
def update_machine(machine_id: int, payload: MachineUpdate, db: Session = Depends(get_db)):
    """
    Partially update a machine. If skill_requirements is provided, it fully replaces existing ones.

    Input  : machine_id (path param), MachineUpdate JSON body (all fields optional).
    Output : Updated MachineOut; raises HTTP 404 if machine does not exist.
    """
    m = db.query(Machine).filter(Machine.id == machine_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Machine not found")
    data = payload.model_dump(exclude_unset=True, exclude={"skill_requirements"})
    for field, value in data.items():
        setattr(m, field, value)
    if payload.skill_requirements is not None:
        _sync_skill_reqs(db, m, payload.skill_requirements)
    db.commit()
    db.refresh(m)
    return m


@router.delete("/{machine_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_machine(machine_id: int, db: Session = Depends(get_db)):
    """
    Hard-delete a machine and all cascade-linked skill requirements and overrides.

    Input  : machine_id (path param).
    Output : HTTP 204 No Content on success; HTTP 404 if machine does not exist.
    """
    m = db.query(Machine).filter(Machine.id == machine_id).first()
    if not m:
        raise HTTPException(status_code=404, detail="Machine not found")
    db.delete(m)
    db.commit()
