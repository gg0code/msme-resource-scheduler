"""
routers/skills.py
-----------------
HTTP route handlers for the Skill Catalogue API (GET, POST, PATCH, DELETE).
Skills are the master reference used by employees, machines, and jobs, so
this router is typically called first during initial data setup.
All routes are mounted at /api/skills/ in main.py.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.skill import Skill
from app.schemas.skill import SkillCreate, SkillUpdate, SkillOut

router = APIRouter()


@router.get("/", response_model=List[SkillOut])
def list_skills(active_only: bool = False, db: Session = Depends(get_db)):
    """
    Return all skills, optionally filtered to active ones only.

    Input  : active_only (query param, default False).
    Output : List of SkillOut objects ordered alphabetically by name.
    """
    q = db.query(Skill)
    if active_only:
        q = q.filter(Skill.is_active == True)
    return q.order_by(Skill.name).all()


@router.get("/{skill_id}", response_model=SkillOut)
def get_skill(skill_id: int, db: Session = Depends(get_db)):
    """
    Fetch a single skill by its primary key.

    Input  : skill_id (path param).
    Output : SkillOut if found; raises HTTP 404 if not.
    """
    skill = db.query(Skill).filter(Skill.id == skill_id).first()
    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")
    return skill


@router.post("/", response_model=SkillOut, status_code=status.HTTP_201_CREATED)
def create_skill(payload: SkillCreate, db: Session = Depends(get_db)):
    """
    Create a new skill in the catalogue.
    Rejects duplicates — skill names must be unique across the catalogue.

    Input  : SkillCreate JSON body (name, category, is_premium, description).
    Output : Newly created SkillOut with assigned id; HTTP 400 if name already exists.
    """
    existing = db.query(Skill).filter(Skill.name == payload.name).first()
    if existing:
        raise HTTPException(status_code=400, detail="Skill with this name already exists")
    skill = Skill(**payload.model_dump())
    db.add(skill)
    db.commit()
    db.refresh(skill)
    return skill


@router.patch("/{skill_id}", response_model=SkillOut)
def update_skill(skill_id: int, payload: SkillUpdate, db: Session = Depends(get_db)):
    """
    Partially update an existing skill.
    Only fields present in the request body are modified (PATCH semantics).

    Input  : skill_id (path param), SkillUpdate JSON body (all fields optional).
    Output : Updated SkillOut; raises HTTP 404 if skill does not exist.
    """
    skill = db.query(Skill).filter(Skill.id == skill_id).first()
    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(skill, field, value)
    db.commit()
    db.refresh(skill)
    return skill


@router.delete("/{skill_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_skill(skill_id: int, db: Session = Depends(get_db)):
    """
    Hard-delete a skill from the catalogue.
    Consider using PATCH to set is_active=False instead, to preserve referential history.

    Input  : skill_id (path param).
    Output : HTTP 204 No Content on success; HTTP 404 if skill does not exist.
    """
    skill = db.query(Skill).filter(Skill.id == skill_id).first()
    if not skill:
        raise HTTPException(status_code=404, detail="Skill not found")
    db.delete(skill)
    db.commit()
