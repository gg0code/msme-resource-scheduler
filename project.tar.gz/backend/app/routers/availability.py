"""
routers/availability.py
-----------------------
HTTP route handlers for the Availability Override API (GET, POST, PATCH, DELETE).
Overrides let proprietors record planned leave for employees and maintenance
windows for machines, which the availability engine then factors into scheduling.
All routes are mounted at /api/availability/ in main.py.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.availability import AvailabilityOverride
from app.schemas.availability import (
    AvailabilityOverrideCreate,
    AvailabilityOverrideUpdate,
    AvailabilityOverrideOut,
)

router = APIRouter()


@router.get("/", response_model=List[AvailabilityOverrideOut])
def list_overrides(employee_id: int = None, machine_id: int = None, db: Session = Depends(get_db)):
    """
    Return availability overrides, optionally filtered by employee or machine.

    Input  : employee_id (query param, optional), machine_id (query param, optional).
    Output : List of AvailabilityOverrideOut objects ordered by date_from ascending.
    """
    q = db.query(AvailabilityOverride)
    if employee_id:
        q = q.filter(AvailabilityOverride.employee_id == employee_id)
    if machine_id:
        q = q.filter(AvailabilityOverride.machine_id == machine_id)
    return q.order_by(AvailabilityOverride.date_from).all()


@router.post("/", response_model=AvailabilityOverrideOut, status_code=status.HTTP_201_CREATED)
def create_override(payload: AvailabilityOverrideCreate, db: Session = Depends(get_db)):
    """
    Create a new availability override for an employee or machine.
    Exactly one of employee_id or machine_id must be provided.

    Input  : AvailabilityOverrideCreate JSON body (resource id, date range, availability_pct, reason).
    Output : Newly created AvailabilityOverrideOut; HTTP 400 if neither resource id is provided.
    """
    if not payload.employee_id and not payload.machine_id:
        raise HTTPException(status_code=400, detail="Must specify either employee_id or machine_id")
    override = AvailabilityOverride(**payload.model_dump())
    db.add(override)
    db.commit()
    db.refresh(override)
    return override


@router.patch("/{override_id}", response_model=AvailabilityOverrideOut)
def update_override(override_id: int, payload: AvailabilityOverrideUpdate, db: Session = Depends(get_db)):
    """
    Partially update an existing availability override (e.g. adjust dates or percentage).

    Input  : override_id (path param), AvailabilityOverrideUpdate JSON body (all fields optional).
    Output : Updated AvailabilityOverrideOut; raises HTTP 404 if override does not exist.
    """
    override = db.query(AvailabilityOverride).filter(AvailabilityOverride.id == override_id).first()
    if not override:
        raise HTTPException(status_code=404, detail="Override not found")
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(override, field, value)
    db.commit()
    db.refresh(override)
    return override


@router.delete("/{override_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_override(override_id: int, db: Session = Depends(get_db)):
    """
    Delete an availability override (e.g. when leave is cancelled).

    Input  : override_id (path param).
    Output : HTTP 204 No Content on success; HTTP 404 if override does not exist.
    """
    override = db.query(AvailabilityOverride).filter(AvailabilityOverride.id == override_id).first()
    if not override:
        raise HTTPException(status_code=404, detail="Override not found")
    db.delete(override)
    db.commit()
