"""
routers/employees.py
--------------------
HTTP route handlers for the Employee Master API (GET, POST, PATCH, DELETE).
Employee creation and updates accept an embedded skill list; the _sync_skills
helper replaces all EmployeeSkill rows atomically within the same transaction.
All routes are mounted at /api/employees/ in main.py.
"""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.database import get_db
from app.models.employee import Employee, EmployeeSkill
from app.schemas.employee import EmployeeCreate, EmployeeUpdate, EmployeeOut

router = APIRouter()


def _sync_skills(db: Session, employee: Employee, skills_data: list):
    """
    Replace all EmployeeSkill rows for the given employee with a new list.
    Called inside create and update routes to keep skills in sync atomically.

    Input  : db session, employee ORM object, list of EmployeeSkillIn objects.
    Output : None — deletes existing EmployeeSkill rows and inserts new ones in-place.
    """
    db.query(EmployeeSkill).filter(EmployeeSkill.employee_id == employee.id).delete()
    for s in skills_data:
        db.add(EmployeeSkill(employee_id=employee.id, skill_id=s.skill_id, skill_level=s.skill_level))


@router.get("/", response_model=List[EmployeeOut])
def list_employees(status: str = None, db: Session = Depends(get_db)):
    """
    Return all employees, optionally filtered by status.

    Input  : status (query param, e.g. "Active", "On Leave"). Optional.
    Output : List of EmployeeOut objects with embedded skills, ordered by name.
    """
    q = db.query(Employee)
    if status:
        q = q.filter(Employee.status == status)
    return q.order_by(Employee.full_name).all()


@router.get("/{employee_id}", response_model=EmployeeOut)
def get_employee(employee_id: int, db: Session = Depends(get_db)):
    """
    Fetch a single employee by primary key.

    Input  : employee_id (path param).
    Output : EmployeeOut with embedded skills; raises HTTP 404 if not found.
    """
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    return emp


@router.post("/", response_model=EmployeeOut, status_code=status.HTTP_201_CREATED)
def create_employee(payload: EmployeeCreate, db: Session = Depends(get_db)):
    """
    Create a new employee and optionally assign skills in one request.
    Uses db.flush() to get the employee ID before inserting EmployeeSkill rows.

    Input  : EmployeeCreate JSON body (employee fields + optional skills list).
    Output : Newly created EmployeeOut with assigned id and embedded skills.
    """
    data = payload.model_dump(exclude={"skills"})
    emp = Employee(**data)
    db.add(emp)
    db.flush()   # Assigns emp.id without committing, needed for FK in EmployeeSkill
    _sync_skills(db, emp, payload.skills)
    db.commit()
    db.refresh(emp)
    return emp


@router.patch("/{employee_id}", response_model=EmployeeOut)
def update_employee(employee_id: int, payload: EmployeeUpdate, db: Session = Depends(get_db)):
    """
    Partially update an employee. If skills list is provided, it fully replaces existing skills.

    Input  : employee_id (path param), EmployeeUpdate JSON body (all fields optional).
    Output : Updated EmployeeOut; raises HTTP 404 if employee does not exist.
    """
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    data = payload.model_dump(exclude_unset=True, exclude={"skills"})
    for field, value in data.items():
        setattr(emp, field, value)
    if payload.skills is not None:
        _sync_skills(db, emp, payload.skills)
    db.commit()
    db.refresh(emp)
    return emp


@router.delete("/{employee_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_employee(employee_id: int, db: Session = Depends(get_db)):
    """
    Hard-delete an employee and all cascade-linked records (skills, overrides).

    Input  : employee_id (path param).
    Output : HTTP 204 No Content on success; HTTP 404 if employee does not exist.
    """
    emp = db.query(Employee).filter(Employee.id == employee_id).first()
    if not emp:
        raise HTTPException(status_code=404, detail="Employee not found")
    db.delete(emp)
    db.commit()
