"""
config.py
---------
Loads all application configuration from the .env file using Pydantic Settings.
A single `settings` instance is imported across the app wherever config values are needed.
Centralising config here ensures no magic strings are scattered across the codebase.
"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """
    Maps every key in .env to a typed Python attribute.
    Pydantic automatically reads from environment variables or the .env file.

    Input  : Environment variables or a .env file on disk.
    Output : A fully validated Settings object with typed, ready-to-use attributes.
    """

    DATABASE_URL: str
    DB_HOST: str = "localhost"
    DB_PORT: int = 5432
    DB_USER: str = "msme_user"
    DB_PASSWORD: str = "msme_pass"
    DB_NAME: str = "msme_scheduler"
    BACKEND_PORT: int = 8000
    FRONTEND_PORT: int = 3000

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


# Module-level singleton — import `settings` anywhere config values are needed.
settings = Settings()
