"""
services/assignment_service.py
-------------------------------
Business logic for manually assigning employees and machines to a job.
Validates every resource before writing to the DB — checking active status,
day-by-day availability overrides, and double-booking against other jobs.
Raises AssignmentError (caught by the router and returned as HTTP 409) on any failure.
"""

from typing import List
from sqlalchemy.orm import Session

from app.models.job import Job, JobAssignment
from app.models.employee import Employee
from app.models.machine import Machine
from app.models.availability import AvailabilityOverride
from app.services.availability_engine import (
    _date_range,
    _is_employee_busy,
    _is_machine_busy,
    _effective_availability,
)


class AssignmentError(Exception):
    """
    Raised when a resource cannot be assigned due to a conflict or validation failure.
    The router catches this and returns it as an HTTP 409 response with the message as detail.
    """
    pass


def assign_resources(
    db: Session,
    job_id: int,
    employee_ids: List[int],
    machine_ids: List[int],
) -> list:
    """
    Validate and assign a list of employees and machines to a job in one atomic operation.
    Existing assignments for the job are cleared first; the new list replaces them entirely.
    If the job was in "Pending Assignment" status, it is promoted to "Scheduled".

    Validation order per employee:
      1. Employee record exists in DB
      2. Employee status is Active
      3. Employee has > 0% availability on every day of the job range
      4. Employee is not already assigned to another overlapping job

    Validation order per machine:
      1. Machine record exists in DB
      2. Machine status is Operational
      3. Machine has > 0% availability on every day of the job range
      4. Machine is not already assigned to another overlapping job

    Input  : db session, job_id (int), employee_ids (list of ints), machine_ids (list of ints).
    Output : List of dicts [{"type": "employee"|"machine", "id": int}, ...] for each assignment created.
             Raises AssignmentError with a descriptive message on the first validation failure found.
    """
    job = db.query(Job).filter(Job.id == job_id).first()
    if not job:
        raise AssignmentError(f"Job {job_id} not found")

    days = _date_range(job.start_date, job.end_date)

    # --- Validate all employees before writing anything ---
    for emp_id in employee_ids:
        emp = db.query(Employee).filter(Employee.id == emp_id).first()
        if not emp:
            raise AssignmentError(f"Employee {emp_id} not found")
        if emp.status != "Active":
            raise AssignmentError(f"Employee '{emp.full_name}' is not Active (status: {emp.status})")

        emp_overrides = (
            db.query(AvailabilityOverride)
            .filter(AvailabilityOverride.employee_id == emp_id)
            .all()
        )
        # Check every day individually so we can name the exact blocked date in the error
        for d in days:
            eff = _effective_availability(emp.base_availability_pct, emp_overrides, d)
            if eff <= 0:
                raise AssignmentError(f"Employee '{emp.full_name}' is unavailable on {d}")

        if _is_employee_busy(db, emp_id, job_id, days):
            raise AssignmentError(
                f"Employee '{emp.full_name}' is already assigned to another job in this date range"
            )

    # --- Validate all machines before writing anything ---
    for machine_id in machine_ids:
        machine = db.query(Machine).filter(Machine.id == machine_id).first()
        if not machine:
            raise AssignmentError(f"Machine {machine_id} not found")
        if machine.status != "Operational":
            raise AssignmentError(f"Machine '{machine.name}' is not Operational (status: {machine.status})")

        machine_overrides = (
            db.query(AvailabilityOverride)
            .filter(AvailabilityOverride.machine_id == machine_id)
            .all()
        )
        for d in days:
            eff = _effective_availability(machine.base_availability_pct, machine_overrides, d)
            if eff <= 0:
                raise AssignmentError(f"Machine '{machine.name}' is unavailable on {d}")

        if _is_machine_busy(db, machine_id, job_id, days):
            raise AssignmentError(
                f"Machine '{machine.name}' is already assigned to another job in this date range"
            )

    # --- All validations passed — clear existing assignments and insert new ones ---
    db.query(JobAssignment).filter(JobAssignment.job_id == job_id).delete()

    created = []
    for emp_id in employee_ids:
        db.add(JobAssignment(job_id=job_id, employee_id=emp_id))
        created.append({"type": "employee", "id": emp_id})

    for machine_id in machine_ids:
        db.add(JobAssignment(job_id=job_id, machine_id=machine_id))
        created.append({"type": "machine", "id": machine_id})

    # Auto-advance job status when it was waiting for assignment
    if job.status == "Pending Assignment":
        job.status = "Scheduled"

    db.commit()
    return created
